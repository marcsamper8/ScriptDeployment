﻿namespace DeploymentScript
{
    partial class SQLLogin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(SQLLogin));
            this.servername = new System.Windows.Forms.TextBox();
            this.pass = new System.Windows.Forms.TextBox();
            this.checkedListBox1 = new System.Windows.Forms.CheckedListBox();
            this.user = new System.Windows.Forms.TextBox();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.tableDataDetailsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.query = new MetroFramework.Controls.MetroTextBox();
            this.button1 = new MetroFramework.Controls.MetroButton();
            this.button5 = new MetroFramework.Controls.MetroButton();
            this.metroLabel1 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel2 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel3 = new MetroFramework.Controls.MetroLabel();
            this.metroButton1 = new MetroFramework.Controls.MetroButton();
            this.resultx = new MetroFramework.Controls.MetroTextBox();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // servername
            // 
            this.servername.Location = new System.Drawing.Point(660, 25);
            this.servername.Name = "servername";
            this.servername.Size = new System.Drawing.Size(62, 20);
            this.servername.TabIndex = 1;
            this.servername.Visible = false;
            this.servername.TextChanged += new System.EventHandler(this.servername_TextChanged);
            // 
            // pass
            // 
            this.pass.Location = new System.Drawing.Point(567, 25);
            this.pass.Name = "pass";
            this.pass.Size = new System.Drawing.Size(38, 20);
            this.pass.TabIndex = 3;
            this.pass.Visible = false;
            this.pass.TextChanged += new System.EventHandler(this.pass_TextChanged);
            // 
            // checkedListBox1
            // 
            this.checkedListBox1.CheckOnClick = true;
            this.checkedListBox1.FormattingEnabled = true;
            this.checkedListBox1.Location = new System.Drawing.Point(19, 96);
            this.checkedListBox1.Name = "checkedListBox1";
            this.checkedListBox1.Size = new System.Drawing.Size(277, 289);
            this.checkedListBox1.Sorted = true;
            this.checkedListBox1.TabIndex = 10;
            this.checkedListBox1.SelectedIndexChanged += new System.EventHandler(this.MultipleSelect);
            // 
            // user
            // 
            this.user.Location = new System.Drawing.Point(611, 25);
            this.user.Name = "user";
            this.user.Size = new System.Drawing.Size(42, 20);
            this.user.TabIndex = 15;
            this.user.Visible = false;
            this.user.TextChanged += new System.EventHandler(this.user_TextChanged);
            // 
            // menuStrip1
            // 
            this.menuStrip1.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem1});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(748, 24);
            this.menuStrip1.TabIndex = 26;
            this.menuStrip1.Text = "menuStrip1";
            this.menuStrip1.Visible = false;
            this.menuStrip1.ItemClicked += new System.Windows.Forms.ToolStripItemClickedEventHandler(this.menuStrip1_ItemClicked);
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tableDataDetailsToolStripMenuItem});
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(72, 20);
            this.toolStripMenuItem1.Text = "SQL Tools";
            this.toolStripMenuItem1.Click += new System.EventHandler(this.toolStripMenuItem1_Click);
            // 
            // tableDataDetailsToolStripMenuItem
            // 
            this.tableDataDetailsToolStripMenuItem.Name = "tableDataDetailsToolStripMenuItem";
            this.tableDataDetailsToolStripMenuItem.Size = new System.Drawing.Size(168, 22);
            this.tableDataDetailsToolStripMenuItem.Text = "Table Data Details";
            this.tableDataDetailsToolStripMenuItem.Click += new System.EventHandler(this.tableDataDetailsToolStripMenuItem_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(371, 391);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(99, 62);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 27;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Visible = false;
            // 
            // query
            // 
            // 
            // 
            // 
            this.query.CustomButton.Image = null;
            this.query.CustomButton.Location = new System.Drawing.Point(189, 2);
            this.query.CustomButton.Name = "";
            this.query.CustomButton.Size = new System.Drawing.Size(329, 329);
            this.query.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.query.CustomButton.TabIndex = 1;
            this.query.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.query.CustomButton.UseSelectable = true;
            this.query.CustomButton.Visible = false;
            this.query.Lines = new string[0];
            this.query.Location = new System.Drawing.Point(319, 51);
            this.query.MaxLength = 99999999;
            this.query.Multiline = true;
            this.query.Name = "query";
            this.query.PasswordChar = '\0';
            this.query.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.query.SelectedText = "";
            this.query.SelectionLength = 0;
            this.query.SelectionStart = 0;
            this.query.ShortcutsEnabled = true;
            this.query.Size = new System.Drawing.Size(521, 334);
            this.query.TabIndex = 28;
            this.query.UseSelectable = true;
            this.query.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.query.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(747, 397);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(93, 40);
            this.button1.TabIndex = 30;
            this.button1.Text = "Run";
            this.button1.UseSelectable = true;
            this.button1.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(647, 397);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(94, 40);
            this.button5.TabIndex = 31;
            this.button5.Text = "Clear";
            this.button5.UseSelectable = true;
            this.button5.Click += new System.EventHandler(this.button5_Click_1);
            // 
            // metroLabel1
            // 
            this.metroLabel1.AutoSize = true;
            this.metroLabel1.Location = new System.Drawing.Point(19, 71);
            this.metroLabel1.Name = "metroLabel1";
            this.metroLabel1.Size = new System.Drawing.Size(68, 19);
            this.metroLabel1.TabIndex = 34;
            this.metroLabel1.Text = "Databases";
            // 
            // metroLabel2
            // 
            this.metroLabel2.AutoSize = true;
            this.metroLabel2.Location = new System.Drawing.Point(319, 26);
            this.metroLabel2.Name = "metroLabel2";
            this.metroLabel2.Size = new System.Drawing.Size(42, 19);
            this.metroLabel2.TabIndex = 35;
            this.metroLabel2.Text = "Script";
            this.metroLabel2.Click += new System.EventHandler(this.metroLabel2_Click);
            // 
            // metroLabel3
            // 
            this.metroLabel3.AutoSize = true;
            this.metroLabel3.Location = new System.Drawing.Point(12, 426);
            this.metroLabel3.Name = "metroLabel3";
            this.metroLabel3.Size = new System.Drawing.Size(43, 19);
            this.metroLabel3.TabIndex = 36;
            this.metroLabel3.Text = "Result";
            // 
            // metroButton1
            // 
            this.metroButton1.Location = new System.Drawing.Point(747, 15);
            this.metroButton1.Name = "metroButton1";
            this.metroButton1.Size = new System.Drawing.Size(93, 30);
            this.metroButton1.TabIndex = 37;
            this.metroButton1.Text = "Disconnect";
            this.metroButton1.UseSelectable = true;
            this.metroButton1.Click += new System.EventHandler(this.metroButton1_Click);
            // 
            // resultx
            // 
            // 
            // 
            // 
            this.resultx.CustomButton.Image = null;
            this.resultx.CustomButton.Location = new System.Drawing.Point(680, 2);
            this.resultx.CustomButton.Name = "";
            this.resultx.CustomButton.Size = new System.Drawing.Size(145, 145);
            this.resultx.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.resultx.CustomButton.TabIndex = 1;
            this.resultx.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.resultx.CustomButton.UseSelectable = true;
            this.resultx.CustomButton.Visible = false;
            this.resultx.Lines = new string[0];
            this.resultx.Location = new System.Drawing.Point(12, 448);
            this.resultx.MaxLength = 32767;
            this.resultx.Multiline = true;
            this.resultx.Name = "resultx";
            this.resultx.PasswordChar = '\0';
            this.resultx.ReadOnly = true;
            this.resultx.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.resultx.SelectedText = "";
            this.resultx.SelectionLength = 0;
            this.resultx.SelectionStart = 0;
            this.resultx.ShortcutsEnabled = true;
            this.resultx.Size = new System.Drawing.Size(828, 150);
            this.resultx.TabIndex = 38;
            this.resultx.UseSelectable = true;
            this.resultx.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.resultx.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            this.resultx.TextChanged += new System.EventHandler(this.resultx_TextChanged_1);
            this.resultx.VisibleChanged += new System.EventHandler(this.resultx_VisibleChanged);
            // 
            // SQLLogin
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(863, 619);
            this.Controls.Add(this.resultx);
            this.Controls.Add(this.metroButton1);
            this.Controls.Add(this.metroLabel3);
            this.Controls.Add(this.metroLabel2);
            this.Controls.Add(this.metroLabel1);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.user);
            this.Controls.Add(this.checkedListBox1);
            this.Controls.Add(this.pass);
            this.Controls.Add(this.servername);
            this.Controls.Add(this.query);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.menuStrip1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.menuStrip1;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Movable = false;
            this.Name = "SQLLogin";
            this.Resizable = false;
            this.Text = "SCRIPT DEPLOYMENT";
            this.Load += new System.EventHandler(this.SQLLogin_Load);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.SQLLogin_KeyDown);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.TextBox servername;
        private System.Windows.Forms.TextBox pass;
        private System.Windows.Forms.CheckedListBox checkedListBox1;
        private System.Windows.Forms.TextBox user;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem tableDataDetailsToolStripMenuItem;
        private System.Windows.Forms.PictureBox pictureBox1;
        private MetroFramework.Controls.MetroTextBox query;
        private MetroFramework.Controls.MetroButton button1;
        private MetroFramework.Controls.MetroButton button5;
        private MetroFramework.Controls.MetroLabel metroLabel1;
        private MetroFramework.Controls.MetroLabel metroLabel2;
        private MetroFramework.Controls.MetroLabel metroLabel3;
        private MetroFramework.Controls.MetroButton metroButton1;
        private MetroFramework.Controls.MetroTextBox resultx;
    }
}

