﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.SqlServer.Management.Smo;
using System.Threading;
using Microsoft.SqlServer.Management.Common;

namespace DeploymentScript
{

    public partial class SQLLogin : MetroFramework.Forms.MetroForm
    {
        string serverName;
        public SqlConnectionStringBuilder connectionString = new SqlConnectionStringBuilder();
        BackgroundWorker bgw = new BackgroundWorker();
        public static string server = "";
        public static string uname = "";
        public static string pword = "";
        public static string dbase = "";
        private Thread threadInput = null;
        public SQLLogin()
        {
            InitializeComponent();
            query.ScrollBars = ScrollBars.Both;
            resultx.ScrollBars = ScrollBars.Both;
            servername.Text = SQLLogin.server;
            user.Text = SQLLogin.uname;
            pass.Text = SQLLogin.pword;
           
        }

        private void button1_Click(object sender, EventArgs e)
        {

            try
            {
                Thread threadInput = new Thread(RunSQLQuery);
                threadInput.Start();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
                threadInput.Abort();
            }


            //

        }

        private void SQLLogin_Load(object sender, EventArgs e)
        {
            addDataToChecklist();
            this.ControlBox = false;
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
           
        }

        private void button2_Click(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < checkedListBox1.Items.Count; i++)
            {
                checkedListBox1.SetItemChecked(i, true);
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < checkedListBox1.Items.Count; i++)
            {
                checkedListBox1.SetItemChecked(i, false);
            }
        }

      
 

        private void button2_Click_1(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            resultx.Text = string.Empty;
            query.Text = string.Empty;
        }



        private void pass_TextChanged(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void user_TextChanged(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void servername_TextChanged(object sender, EventArgs e)
        {

        }

        private void menuStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        private void toolStripMenuItem1_Click(object sender, EventArgs e)
        {

        }

        private void tableDataDetailsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            server = servername.Text;
            uname = user.Text;
            pword = pass.Text;
            dbase = SQLMainPage.dbase_name;

        }

        public void addDataToChecklist()
        {
            checkedListBox1.Items.Clear();
            foreach (String item in GetDatabaseList())
            {
                checkedListBox1.Items.Add(item);
            }
        
        }

        public List<string> GetDatabaseList()
        {
            List<string> list = new List<string>();

            // Open connection to the database
            string connetionString_1 = "Data Source=" + SQLMainPage.Server_name + ";Initial Catalog=" + SQLMainPage.dbase_name + ";User ID=" + SQLMainPage.User_name + ";Password=" + SQLMainPage.pword_name;

            using (SqlConnection con = new SqlConnection(connetionString_1))
            {
                con.Open();

                // Set up a command with the given query and associate
                // this with the current connection.
                using (SqlCommand cmd = new SqlCommand("SELECT name from sys.databases WHERE suser_sname(owner_sid) LIKE '%"+ SQLMainPage.User_name+ "%'", con))
                {
                    using (IDataReader dr = cmd.ExecuteReader())
                    {
                        while (dr.Read())
                        {
                            list.Add(dr[0].ToString());
                        }
                    }
                }
            }
            return list;

        }

        private void SetLoading(bool displayLoader)
        {
            if (displayLoader)
            {
                this.Invoke((MethodInvoker)delegate
                {
                    query.Enabled = false;
                    //resultx.Enabled = false;
                    checkedListBox1.Enabled = false;  
                    button1.Enabled = false;
                    metroButton1.Enabled = false;
                  
                    button5.Enabled = false;
                    pictureBox1.Visible = true;
                    //this.Cursor = System.Windows.Forms.Cursors.WaitCursor;
                });
            }
            else
            {
                this.Invoke((MethodInvoker)delegate
                {
                    query.Enabled = true;
                    //resultx.Enabled = true;
                    checkedListBox1.Enabled = true;
                    button1.Enabled =true;
                    button5.Enabled =true;
                    metroButton1.Enabled = true;
                    pictureBox1.Visible = false;
                   // this.Cursor = System.Windows.Forms.Cursors.Default;
                });
            }
        }

        private void RunSQLQuery ()
        {
           
            SetLoading(true);
            string connetionString = null;
            string serverName = SQLMainPage.Server_name;
            string username = SQLMainPage.User_name;
            string password = SQLMainPage.pword_name;
            string result = null;
            string queryString = @query.Text;


            string[] splitter = new string[] { "\r\nGO\r\n" };
            string[] commandTexts = queryString.Split(splitter,
            StringSplitOptions.RemoveEmptyEntries);
          


            int count = 0;
            if (query.Text == "")
            {
                result += "No Query Executed";
            }
            else
            {

                foreach (int indexChecked in checkedListBox1.CheckedIndices)
                {
                    if (checkedListBox1.GetItemCheckState(indexChecked) == CheckState.Checked)
                    {
                        count++;
                    }
                    if (count > 0)
                    {
                        try
                        {

                            SqlConnection cnn;
                            connetionString = @"Data Source=" + serverName + ";Initial Catalog=" + checkedListBox1.Items[indexChecked] + ";User ID=" + username + ";Password=" + password;
                            cnn = new SqlConnection(connetionString);
                            string SQLerr_msg = string.Empty;
                            SqlCommand command = new SqlCommand(queryString, cnn);

                           
                            //cnn.Open();
                            //SqlDataReader reader = command.ExecuteReader();
                           
                            try
                            {
                                    SqlConnection sqlConnection = new SqlConnection(connetionString);
                                    ServerConnection svrConnection = new ServerConnection(sqlConnection);
                                    Server server = new Server(svrConnection);
                                    try
                                    {
                                        server.ConnectionContext.ExecuteNonQuery(queryString);
                                        result += "[" + checkedListBox1.Items[indexChecked] + "] : " + "Query executed successfully." + Environment.NewLine;
                                            
                                         SetText(result.ToString());
                                    }
                                    catch (SqlException ex)
                                    {
                                    DataSet ds = server.ConnectionContext.ExecuteWithResults(queryString);
                                    result += "[" + checkedListBox1.Items[indexChecked]  +"] : "+  ex.Message +  Environment.NewLine;
                                         SetText(result.ToString());
                                     }
                                    catch (Exception ee)
                                    {

                                    sqlConnection.InfoMessage += delegate(object sender, SqlInfoMessageEventArgs e)
                                    {
                                        result += "\n" + e.Message;                                   
                                    };

                                    result += "[" + checkedListBox1.Items[indexChecked] + "] : " + ee.Message + Environment.NewLine;
                                    SetText(result.ToString());

                                }
                            }
                            catch (SqlException exx)
                            {
                                //DataSet dsx = server.ConnectionContext.ExecuteWithResults(queryString);
                                result += "[" + checkedListBox1.Items[indexChecked] + "] : " + exx.Message + Environment.NewLine;
                                SetText(result.ToString());

                            }
                        }
                        catch (SqlException exc)
                        {
                            result += "[" + checkedListBox1.Items[indexChecked] + "] : " + exc.Message + Environment.NewLine;
                            SetText(result.ToString());
                        }
                    }
                    else
                    {
                        result += "No Database Selected";
                        SetText(result.ToString());
                    }


                }

            }
           
            SetLoading(false);
            threadInput.Abort();
         
        }
        delegate void SetTextCallback(string text);
        private void SetText(string text)
        {
            // InvokeRequired required compares the thread ID of the
            // calling thread to the thread ID of the creating thread.
            // If these threads are different, it returns true.

                if (this.resultx.InvokeRequired)
                {
                    SetTextCallback d = new SetTextCallback(SetText);
                    this.Invoke(d, new object[] { text });
                }
                else
                {
                    this.resultx.Text = text;
                }
           
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            try
            {
                threadInput = new Thread(RunSQLQuery);
                threadInput.Start();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
                threadInput.Abort();
            }
        }

        private void button5_Click_1(object sender, EventArgs e)
        {
            resultx.Text = string.Empty;
            query.Text = string.Empty;
        }

        private void button3_Click_1(object sender, EventArgs e)
        {

        }

        private void button4_Click_1(object sender, EventArgs e)
        {

        }

        private void metroButton1_Click(object sender, EventArgs e)
        {

            DialogResult dr = MetroFramework.MetroMessageBox.Show(this, "\nDo you want to disconnect?", "Script Deployment", MessageBoxButtons.YesNo, MessageBoxIcon.Information);
            if (dr == DialogResult.Yes)
            {
                this.Close();
            }
            else
            {
                
            }
           
            
        }

        private void metroLabel2_Click(object sender, EventArgs e)
        {

        }
        private int mLastSelection;
        private void MultipleSelect(object sender, EventArgs e)
        {
            if ((Form.ModifierKeys & Keys.Shift) == Keys.Shift)
            {

                bool value = true;
                
                if (mLastSelection >= 0 && mLastSelection < checkedListBox1.Items.Count)
                    value = checkedListBox1.GetItemChecked(mLastSelection);
                if (mLastSelection > checkedListBox1.SelectedIndex)
                    for (int ix = checkedListBox1.SelectedIndex; ix < mLastSelection; ++ix)
                        checkedListBox1.SetItemChecked(ix, value);
                else
                    for (int ix = mLastSelection; ix <= checkedListBox1.SelectedIndex; ++ix)
                        checkedListBox1.SetItemChecked(ix, value);
            }
            mLastSelection = checkedListBox1.SelectedIndex;
        }

        private void resultx_TextChanged(object sender, EventArgs e)
        {
   
        }

        private void resultx_TextChanged_1(object sender, EventArgs e)
        {
           
        }

        private void resultx_VisibleChanged(object sender, EventArgs e)
        {

        }

        private void SQLLogin_KeyDown(object sender, KeyEventArgs e)
        {

        }
    }
}
