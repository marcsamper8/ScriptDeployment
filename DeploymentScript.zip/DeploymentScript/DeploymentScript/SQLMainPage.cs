﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.SqlServer.Management.Smo;
using MetroFramework.Components;
using MetroFramework.Forms;
using MetroFramework;
using System.Threading;
using System.IO;

namespace DeploymentScript
{
    public partial class SQLMainPage : MetroFramework.Forms.MetroForm
    {
        public static string Server_name = "";
        public static string User_name = "";
        public static string pword_name = "";
        public static string dbase_name = "";
        private Thread threadInput = null;
        public SQLMainPage()
        {
            InitializeComponent();
           
        }

        private void SQLMainPage_Load(object sender, EventArgs e)
        {

              

            int counter = 0;
            string line;
            List<string> items = new List<string>();
            this.ControlBox = false;
            string x = File.Exists("SavedConfig.txt") ? "File exists." : "File does not exist.";
            if(x == "File exists.")
            {
                remember.Checked = true;

                System.IO.StreamReader file = new System.IO.StreamReader(@"SavedConfig.txt");
                 while ((line = file.ReadLine()) != null)
                {
                    items.Add(line.Split(',')[0]);
                    counter++;
                }

                
                textBox1.Text = items[0];
                textBox2.Text = items[1];
                textBox3.Text = items[2];

                file.Close();

                //if (textBox1.Text != "" && textBox2.Text != "" && textBox3.Text != "" && metroComboBox1.Text == "")
                //{
                //    LoadComboX();
                //}
            }
            else
            {
                remember.Checked = false;
            }




         
        }



        private void SetLoading(bool displayLoader)
        {
            if (displayLoader)
            {
                this.Invoke((MethodInvoker)delegate
                {
                    textBox1.Enabled = false;
                    textBox2.Enabled = false;
                    textBox3.Enabled = false;
                    button1.Enabled = false;
                    metroButton1.Enabled = false;
                    pictureBox1.Visible = true;
                   
                });
            }
            else
            {
                this.Invoke((MethodInvoker)delegate
                {
                    textBox1.Enabled = true;
                    textBox2.Enabled = true;
                    textBox3.Enabled = true;
                    button1.Enabled = true;
                    metroButton1.Enabled = true;
                    pictureBox1.Visible = false;
   
                });
            }
        }

        private void Login()
        {
            SetLoading(true);
            string servername = textBox1.Text;
            string uname = textBox2.Text;
            string pword = textBox3.Text;
            string dbase = "master";

            string connetionString;
            SqlConnection cnn;
            connetionString = @"Data Source=" + servername + ";Initial Catalog=" + dbase + ";User ID=" + uname + ";Password=" + pword;
            cnn = new SqlConnection(connetionString);
            try
            {
                cnn.Open();

            
                MetroFramework.MetroMessageBox.Show(this, "Connected to " + servername +".", "Login Success");
               

                Server_name = servername;
                User_name = uname;
                pword_name = pword;
                dbase_name = dbase;


                bool checkifExist = File.Exists("dbaseconfigX.txt") ? true : false;
                

                if (!checkifExist)
                {
                    if (remember.Checked)
                    {
                        RememberMe();
                    }
                }


                SQLLogin main = new SQLLogin();
                SQLMainPage gg = new SQLMainPage();
                main.ShowDialog();

            }

            catch (SqlException ex)
            {
                MetroFramework.MetroMessageBox.Show(this,ex.Message,"Login Failed" );
              
               
            }


          SetLoading(false);
          cnn.Close();
           
        }

     
        private void button1_Click_1(object sender, EventArgs e)
        {
            try
            {
                threadInput = new Thread(Login);
                threadInput.Start();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
                threadInput.Abort();
            }
        }

        public List<string> GetDatabaseList()
        {
            List<string> list = new List<string>();

            // Open connection to the database
            string connetionString_1 = "Data Source=" + textBox1.Text + ";Initial Catalog=master;User ID=" + textBox2.Text + ";Password=" + textBox3.Text;

            using (SqlConnection con = new SqlConnection(connetionString_1))
            {
                con.Open();

                // Set up a command with the given query and associate
                // this with the current connection.
                using (SqlCommand cmd = new SqlCommand("SELECT name from sys.databases", con))
                {
                    using (IDataReader dr = cmd.ExecuteReader())
                    {
                        while (dr.Read())
                        {
                            list.Add(dr[0].ToString());
                        }
                    }
                }
            }
            return list;

        }

        private void FormHandler_Form1Hide()
        {
            if (InvokeRequired)
            {
                this.Invoke(new Action(() => { FormHandler_Form1Hide(); }));
            }
            else
            {
                Hide();
            }
        }

        private void metroButton1_Click(object sender, EventArgs e)
        {
           
            

            DialogResult dr = MetroFramework.MetroMessageBox.Show(this, "\nDo you want to Close?", "Script Deployment", MessageBoxButtons.YesNo, MessageBoxIcon.Information);
            if (dr == DialogResult.Yes)
            {
                Application.Exit();
            }
            else
            {

            }

        }
        public void RememberMe()
        {
            string filename = "SavedConfig.txt";
                using (StreamWriter sw = File.CreateText(filename))
                {
                    sw.WriteLine(textBox1.Text);
                    sw.WriteLine(textBox2.Text);
                    sw.WriteLine(textBox3.Text);
                }
         }

        private void textBox3_Click(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {
           
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
           
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            
        }

    }
}
